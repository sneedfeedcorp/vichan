<?php
@define('TINYBOARD', 'xD');
require_once('vendor/autoload.php');
